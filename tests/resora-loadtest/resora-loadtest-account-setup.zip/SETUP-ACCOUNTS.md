# RESORA — Preparation of 50 synthetic SR accounts (DEV only)

These files are ADDITIONS to the existing `resora/tests/resora-loadtest` directory.
Do not replace the previously supplied `loadtest.js` and `README.md`.

## Files

- `sr-loadtest-50.csv`: 50 **identifiers**, names, emails, and organizational assignments. NO passwords.
- `convert-credentials.py`: converts a successfully **COMMITTED** RESORA private
  SR-provisioning credentials.csv export into `accounts.local.json` for k6.
- `.gitignore`: prevents locally generated passwords and reports from being committed.

## IMPORTANT: provisioning is not yet wired to remote DEV

The existing repository command `sr:provision` is intentionally **local-scratch-only**.
Do NOT point it at remote Supabase or remove its local-only guard. Have Codex add
a separately guarded DEV-only runner that reuses `provisionSrAccounts`; the code
must verify the target Supabase DEV project reference, never use production
environment fallbacks, default to read-only dry-run, require explicit approval
for apply, and leave private credential export in the repo's `.private/` directory.

Do not use raw SQL to insert accounts or store plaintext passwords in PostgreSQL.

## Accounts

- NIMs: `lt_resora_20261014_001` through `_050`
- Email: reserved example.com addresses (not real recipients)
- Department: `RND`
- Position: `ANGGOTA`
- Building: `A`
- Active: `true`

These are accepted by RESORA's `parseSrCsv` schema **if the department,
position and building references are present and active in the DEV DB**.
The provisioning dry-run will verify those references before any writes.

## Once guarded DEV-only provisioning succeeds

1. Verify a private export such as:
   `<repo>/.private/sr-provisioning/<uuid>/credentials.csv` and adjacent
   `status.json` with `state: "COMMITTED"`.
2. In PowerShell, navigate to the existing `tests/resora-loadtest` directory:
   `py -3 .\convert-credentials.py "<repo>\.private\sr-provisioning\<uuid>\credentials.csv"`
3. The converter verifies the roster, count and SHA256 before creating
   `accounts.local.json`, without printing usernames or passwords.
4. The existing k6 script can then read `accounts.local.json`.
5. Confirm the DEV **API deployment** and **DEV DB isolation** before setting
   `APPROVE_ISOLATED_TARGET=yes`.

Do not send credential files to a chat, do not commit private exports, and
do not run load tests against Production.
